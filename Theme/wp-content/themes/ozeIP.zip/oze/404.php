<?php get_header(); ?>
<?php the_post(); ?>

<div class="col-12 text-center">
	<h1>Błąd 404</h1>
	<h3>Takiej strony tutaj nie ma :'(</h3>
</div>

<?php get_footer(); ?>