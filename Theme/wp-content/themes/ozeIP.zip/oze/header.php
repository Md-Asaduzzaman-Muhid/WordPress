<!DOCTYPE html>
<html>
<head>
	<?php $GA = array(); include('resources/header_basic.php') ?>
	<?php wp_head();?>
	<script src="https://cdn.jsdelivr.net/npm/jquery-lazyload@1.9.7/jquery.lazyload.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>
<body <?php body_class(); ?>>
<header class="header">
	<div class="header-top">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<a href="<?php echo get_site_url() ?>"><img class="header-logo" src="<?php echo get_template_directory_uri() ?>/img/logo.png" alt="logo"></a>
				</div>
				<div class="col-md-3">
					<div class="phone-number d-flex align-items-center justify-content-end h-100">
						<div class="icon">
							<img src="<?php echo get_template_directory_uri() ?>/img/icons/phone.png" alt="phoneicon">
						</div>
						<div class="number">
							<?php if(!empty(get_field('phone',18))){ ?>
							<a href="tel:<?php echo str_replace(array('(',')',' ','-','.'), "", get_field('phone',18)); ?>"><?php echo get_field('phone',18); ?></a>
							<?php } ?>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="promo h-100 d-flex justify-content-start align-items-center">
						<?php if(!empty(get_field('company_slogan',18))){ ?>
							<?php echo get_field('company_slogan',18); ?>
						<?php } ?>
					</div>
				</div>
				<div class="col-md-2">
				<ul class="text-right social-link m-0 p-0 h-100">
						<li class="wow zoomIn list-inline-item">
							<a href="mailto:<?php echo trim(get_field('email',18)); ?>"><img src="<?php echo get_template_directory_uri() ?>/img/icons/mail.png" alt="mail"></a>
						</li>
						<?php 
						$social_media_group =  get_field('social_media_group',18);
						?>
						<?php if (!empty($social_media_group['facebook'])){ ?>
							<li class="wow zoomIn list-inline-item">
								<a href="<?php echo $social_media_group['facebook']; ?>" target="_blank">
								<img src="<?php echo get_template_directory_uri(); ?>/img/icons/facebook.png" alt="facebook">
								</a>
							</li>
						<?php } ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div id="topMenu" class="header-menu">
		<div class="menu-wrapper">
			<div class="container">
				<?php wp_nav_menu(
					array(
						'theme_location'  => 'top-menu',
						'container_class' => 'collapse navbar-collapse',
						'container_id'    => 'navbarToggleExternalContent',
						'menu_class'      => 'navbar-nav'
					)
				); ?>
			</div>	
		</div>
	</div>
</header>
