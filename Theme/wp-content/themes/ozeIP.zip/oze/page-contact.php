<?php 
/*
Template Name: Contact
*/
get_header(); ?>


<section class="page-section pt-5">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="contact-area wow fadeInLeft">
					<img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/assets/img/logo-yellow.png" alt="logo">
					<h4 class="section-subtitle pt-3">Organizujesz wydarzenie?<br> Potrzebujesz wsparcia technicznego?</h4>
					<h3 class="section-title">Skontaktuj się!</h3>
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<?php get_template_part( 'template-parts/content', 'page' ); ?>
					<?php endwhile; endif; ?>


					<?php if(!empty(get_field('phone'))){ ?>
					<dl>
					<dt><img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/assets/img/page-icon.png" alt="info"></dt>
						<dd>
							<a class="phone" href="tel:<?php echo str_replace(array('(',')',' ','-','.'), "", get_field('phone')); ?>"><?php echo wordwrap(get_field('phone',19),3,' ',true); ?></a>
						</dd>
					</dl>
					<?php } ?>
					<?php if(!empty(get_field('email'))){ ?>
					<dl>
					<dt><img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/assets/img/page-icon.png" alt="info"></dt>
						<dd>
							<a href="mailto:<?php echo trim(get_field('email')); ?>">
								<?php echo trim(get_field('email')); ?>
							</a>
						</dd>
					</dl>
					<?php } ?>
				</div>

				<div class="wow fadeInRight mb-15">
					<?php if(!empty(get_option('office_hour'))){ ?>
						<?php echo trim(get_option('office_hour')); ?>
					<?php } ?>
				</div>

			</div>

			<div class="col-md-8 wow fadeInRight">
				<div class="contact-form">
					<?php echo do_shortcode('[contact-form-7 id="2308c1a" title="Contact form"]'); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="cechy-section">
    <div class="container">
        <?php
			$args = array( 
			'post_type' => 'cecha', 
			'posts_per_page' => 5, 
			'orderby' => 'menu_order', 
			'order' => 'ASC' );
			$loop = new WP_Query( $args );
			$i = 1;
		?>
        <ul class="list-unstyled d-flex justify-content-xl-between justify-content-center flex-wrap mb-0">
            <?php while ( $loop->have_posts() ) : $loop->the_post();?>
            <li class="wow bounceInUp" data-wow-delay="0.<?php echo $i+1; ?>s" >
                <?php if ( get_the_post_thumbnail() ) : ?>									    
                    <?php the_post_thumbnail(); ?>
                <?php endif; ?>
                <h2><?php the_title(); ?></h2>
                <?php if(get_the_content()) : the_content(); endif;?>
            </li>
            <?php $i++; endwhile; ?>
        </ul>
    </div>
</section>

<?php get_footer(); ?>
