jQuery(document).ready(function($) {
    
    /*  Header Sticky
    ============================================= */
    window.onscroll = function() {myFunction()};
    var header = document.getElementById("topMenu");
    var sticky = header.offsetTop;

    function myFunction() {
        if (window.pageYOffset > sticky) {
            header.classList.add("sticky");
        } else {
            header.classList.remove("sticky");
        }
    }

    /*  Window scroll function
    ============================================= */
    let a = 0;
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        let oTop = $('#counter').offset().top - window.innerHeight;
       //Md.Asaduzzaman Muhid
        if (a == 0 && scroll > oTop) {
            $('.counter').each(function() {
                let $this = $(this);
                jQuery({ Counter: 0 }).animate({ Counter: $this.text() }, {
                    duration: 2000,
                    easing: 'swing',
                    step: function () {
                        $this.text(Math.ceil(this.Counter));
                    }
                });
                a=1;
            });
        }
        if (scroll > 700) {
            $('.totop').css('bottom', '55px');
        } else {
            $('.totop').css('bottom', '-50px');
        } 
   });

   $('.totop').click(function(){
       $('html,body').animate({
           scrollTop: 0
       }, 1500);
   })
   

});







var map = L.map('map');
map.setView(new L.LatLng(50.83322306601526, 19.06653821433392), 15);
var routes = Array();
var osmUrl = 'https://{s}.tiles.mapbox.com/v3/examples.map-20v6611k/{z}/{x}/{y}.png';
var osm = new L.TileLayer(osmUrl, {
    minZoom: 5,
    maxZoom: 18,
    opacity: 0.7,
});

var shopIcon = L.icon({

    iconUrl: '../oze/wp-content/themes/oze/img/icons/map-inside.png',

    iconSize:     [116, 150], // size of the icon
    iconAnchor:   [22, 94], // point of the icon which will correspond to marker's location
    shadowAnchor: [4, 62],  // the same for the shadow
    popupAnchor:  [-3, -76] // point from which the popup should open relative to the iconAnchor
});
L.marker([50.83322306601526, 19.06653821433392], {icon: shopIcon}).addTo(map);
var OpenStreetMap_DE = L.tileLayer('https://{s}.tile.openstreetmap.de/tiles/osmde/{z}/{x}/{y}.png', {
	maxZoom: 18,
	attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
});

var Stadia_StamenTonerLite = L.tileLayer('https://tiles.stadiamaps.com/tiles/stamen_toner_lite/{z}/{x}/{y}{r}.{ext}', {
	minZoom: 0,
	maxZoom: 20,
	attribution: '&copy; <a href="https://www.stadiamaps.com/" target="_blank">Stadia Maps</a> &copy; <a href="https://www.stamen.com/" target="_blank">Stamen Design</a> &copy; <a href="https://openmaptiles.org/" target="_blank">OpenMapTiles</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
	ext: 'png'
});

// map.addLayer(OpenStreetMap_DE);
map.addLayer(Stadia_StamenTonerLite);

// points
map.addLayer(routes);
