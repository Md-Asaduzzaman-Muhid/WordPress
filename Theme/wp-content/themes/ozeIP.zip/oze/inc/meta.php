<div class="post-meta">
	<?php the_time('F j, Y') ?>
	<?php //the_author() ?>
	<?php // comments_popup_link('No Comments', '1 Comment', '% Comments', 'comments-link', ''); ?>
</div>
