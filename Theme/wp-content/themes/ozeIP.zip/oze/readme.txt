To run sass:
cd C:\xampp\htdocs\internetplus\oze\wp-content\themes\oze
download ruby and go theme directory run sass --watch sass:.